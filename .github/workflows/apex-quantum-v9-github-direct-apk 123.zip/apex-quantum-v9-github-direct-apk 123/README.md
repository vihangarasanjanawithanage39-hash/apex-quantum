# APEX BINANCE QUANTUM v9 — Direct GitHub Actions Android APK (No PWABuilder)

PWABuilder භාවිත නොකර, කෙළින්ම GitHub හරහා ස්වයංක්‍රීයව Android `.apk` එක Build වී, අනාගතයේ Update ගැසූ සැණින් Auto-Update වන සම්පූර්ණ ව්‍යාපෘතියයි.

## පියවර
1. GitHub හි නව **Public Repository** එකක් සාදන්න (උදා: `apex-quantum`).
2. මෙම ZIP ෆයිල් එක Unzip කර ඇතුළත ඇති සියලුම ෆයිල් හා ෆෝල්ඩර (`.github`, `android`, `index.html`, ආදිය) `main` branch එකට Push කරන්න.
3. GitHub Repository හි **Settings → Pages → Build and deployment → Source** යටතේ **GitHub Actions** තෝරන්න.
4. **Actions** ටැබ් එකට ගොස් Workflow එක අවසන් වූ පසු **Releases** (හෝ Workflow Artifact) වෙතින් `APEX-Quantum-v9-AutoUpdate.apk` බාගත කර ෆෝන් එකට Install කරගන්න.
5. අනාගතයේදී `index.html` සහ `version.json` වෙනස් කර GitHub වෙත Push කළ සැණින් ඔබේ ෆෝන් එකේ ඇති APK එක ස්වයංක්‍රීයවම අලුත් සංස්කරණයට යාවත්කාලීන වේ!
